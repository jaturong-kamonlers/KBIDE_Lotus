Blockly.Blocks['ultrasonic_setup'] = {
  init: function() {
    this.appendDummyInput()
        .appendField(new Blockly.FieldVariable("Ultrasonic1",null,["Plugin.Ultrasonic"],["Plugin.Ultrasonic"]),"instance")
        .appendField("TRIG")
        .appendField(new Blockly.FieldTextInput("0"), "TRIG")
		.appendField("ECHO")
        .appendField(new Blockly.FieldTextInput("0"), "ECHO")
        .appendField("");
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(220);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['ultrasonic_read_distance_cm'] = {
  init: function() {
    this.appendDummyInput()
        .appendField(new Blockly.FieldVariable("ultrasonic1",null,["Plugin.Ultrasonic"],["Plugin.Ultrasonic"]),"instance")
        .appendField("Distance (cm)");
    this.setOutput(true, "Number");
    this.setColour(230);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};
